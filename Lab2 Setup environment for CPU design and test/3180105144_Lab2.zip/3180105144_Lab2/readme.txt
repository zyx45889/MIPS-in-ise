In the required edition part, there're only .v and .sch files as required.
In the full edition part, there're all the files for the project. If any problems are met, please chech this folder.