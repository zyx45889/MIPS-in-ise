In the full_version folder, there're all the files build dring the experiment.

In the required_version folder, there're only .sym, .sch, .v and .vf files.