In the "additional work" folder, there're the modules required us to do in the final part of the first slides. That includes add32, or32, nor32 and so on.

In the "required edition" folder, there's only .v .sch and .coe files as we are required to submit by the teacher.

In the "full edition" folder, there's all the files built in this project, including:

1.Multi_8CH32: project buildt for lab1
2.lab2: project built for lab2
3.lab2_ngc: ngc files used for lab2

The three folds contain the simulation files and project in folder "lab2" could be generated. If any problem was met in "required edition" folder, please check the "full edition" folder for more information.