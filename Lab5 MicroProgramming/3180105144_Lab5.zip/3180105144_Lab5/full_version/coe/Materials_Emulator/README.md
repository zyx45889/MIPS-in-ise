# ZJUQSII Sword Emulator

- scpu_demo_2018.coe为lab中的程序，D_mem.coe为数据文件。可以勾选哈佛结构查看模拟的实验结果。
- 其他的coe文件均不需要数据文件，可以使用冯诺伊曼结构加载到RAM中，或者勾选哈佛结构使用D_mem.coe作为数据文件。
